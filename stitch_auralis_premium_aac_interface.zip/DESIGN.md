---
name: Clinical Luxe
colors:
  surface: '#f6fafe'
  surface-dim: '#d6dade'
  surface-bright: '#f6fafe'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f4f8'
  surface-container: '#eaeef2'
  surface-container-high: '#e4e9ed'
  surface-container-highest: '#dfe3e7'
  on-surface: '#171c1f'
  on-surface-variant: '#45464d'
  inverse-surface: '#2c3134'
  inverse-on-surface: '#edf1f5'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#191c1e'
  on-tertiary-container: '#818486'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#e0e3e5'
  tertiary-fixed-dim: '#c4c7c9'
  on-tertiary-fixed: '#191c1e'
  on-tertiary-fixed-variant: '#444749'
  background: '#f6fafe'
  on-background: '#171c1f'
  surface-variant: '#dfe3e7'
typography:
  display-lg:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  title-md:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  caption:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
  stack-sm: 12px
  stack-md: 24px
  stack-lg: 48px
---

## Brand & Style
The design system moves beyond functional utility into a "Clinical Luxe" aesthetic. It balances the cold precision of high-end medical instrumentation with the sophisticated comfort of a premium wellness environment. The target audience includes clinicians and patients who value clarity, reliability, and a high-status user experience.

The style is a fusion of **Minimalism** and **Modern Corporate**, utilizing heavy whitespace and a refined tonal palette to reduce cognitive load. The emotional response should be one of "calm authority"—the interface feels expensive, intentional, and impeccably accurate.

## Colors
The palette abandons stark #FFFFFF for **Porcelain**, providing a softer, more sophisticated background that reduces eye strain while maintaining high contrast. 

- **Primary (Deep Navy):** Used for typography, primary actions, and brand-critical iconography to establish authority.
- **Secondary (Slate):** Used for supporting text, borders, and secondary UI elements.
- **Surface (Porcelain):** The base canvas for the entire application.
- **Neutral (Light Slate):** Used for subtle background layering and disabled states.

## Typography
Atkinson Hyperlegible Next is the cornerstone of the system, chosen for its unparalleled readability in critical medical contexts and its distinctive, technical character. 

Hierarchy is established through weight and scale rather than color shifts. Headlines use tighter letter-spacing and bold weights to feel architectural. Body text maintains generous line heights to ensure maximum legibility for complex data. All labels and functional text use the "Medium" or "Semibold" weights to differentiate them from prose.

## Layout & Spacing
This design system utilizes a **Fixed Grid** model for desktop to maintain a "dashboard" feel typical of high-end medical hardware. 

- **Desktop:** 12-column grid with a 1280px max-width. Large 64px outer margins create a "framed" gallery effect.
- **Tablet:** 8-column grid with 32px margins.
- **Mobile:** 4-column fluid grid with 20px margins.

Spacing follows a strict 8px rhythmic scale. Components should prioritize vertical "stack" spacing to create a sense of organized, linear progression in medical workflows.

## Elevation & Depth
Depth is conveyed through **Ambient Shadows** and **Tonal Layering**. 

Instead of traditional drop shadows, this system uses "Shadow Pens"—extremely soft, low-opacity (4-8%) blurs with a slight Deep Navy tint to anchor objects to the Porcelain surface. 
- **Level 0 (Surface):** Porcelain background.
- **Level 1 (Cards):** 1px Slate-200 border + 4px blur shadow. Used for standard information blocks.
- **Level 2 (Modals/Popovers):** 12px blur shadow + 1px Slate-300 border.

Surfaces never overlap without a clear tonal or border distinction.

## Shapes
The shape language is **Soft** and precise. A corner radius of 4px (0.25rem) is used for standard components (buttons, inputs) to maintain a professional, "machined" look. Larger containers and cards use 8px (0.5rem) to feel more approachable. Total circularity is reserved exclusively for status indicators and profile avatars.

## Components
- **Buttons:** Primary buttons are Deep Navy with white text; they use a subtle 1px inset top border to simulate a tactile, high-end physical button. Secondary buttons use a Slate border and no fill.
- **Cards:** Defined by a 1px border in #E2E8F0. No heavy background fills; use Porcelain for the card body to maintain a light, airy feel.
- **Inputs:** High-contrast fields with 1px Slate-300 borders. Focus states transition the border to Deep Navy with a 2px outer glow in a very pale slate tint.
- **Lists:** Clean, hair-line separators (1px #F1F5F9). Generous padding (16px top/bottom) to ensure data doesn't feel cramped.
- **Chips:** Used for medical tags or status. These use a very light Slate-100 background with Deep Navy text—no borders, to keep them visually distinct from buttons.
- **Data Visuals:** Charts and graphs should use a refined palette of Slate, Deep Navy, and a single "Action Teal" for highlights, ensuring WCAG AA compliance.